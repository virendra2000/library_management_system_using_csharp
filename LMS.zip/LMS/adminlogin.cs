﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Management_System
{
    public partial class adminlogin : Form
    {
        databaseconn con = new databaseconn();
        string username;
        string password;
        string sql;
        public adminlogin()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            adminregister adr = new adminregister();
            this.Close();
            adr.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            home h = new home();
            this.Close();
            h.Show();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            forgotpassword fg = new forgotpassword();
            this.Close();
            fg.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if(guna2TextBox1.TextLength > 0 && guna2TextBox2.TextLength > 0)
            {
                username = guna2TextBox1.Text;
                password = guna2TextBox2.Text;
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM ADMIN WHERE username='" + username + "' AND password = '" + password + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    dr.Read();
                    logindata.adminname = dr["admin_name"].ToString();
                    logindata.adminaddress = dr["address"].ToString();
                    logindata.adminmobilenum = dr["mobilenumber"].ToString();
                    logindata.adminemail = dr["email"].ToString();
                    logindata.adminusername = dr["username"].ToString();
                    MessageBox.Show("Login Successfully", "Login Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    welcomemsgforadmin wm = new welcomemsgforadmin();
                    this.Close();
                    wm.Show();
                    con.CloseConnection();
                    guna2TextBox1.ResetText();
                    guna2TextBox2.ResetText();
                }
                catch
                {
                    MessageBox.Show("Login Failed", "Login Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    MessageBox.Show("You have not registered Yet", "Librarian Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    adminregister ar = new adminregister();
                    this.Close();
                    ar.Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Input , Please Provide Valid Input","Invalid Field",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
