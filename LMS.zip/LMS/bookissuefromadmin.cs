﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class bookissuefromadmin : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string choice1;
        string choice2;
        string choice3;
        string uid;
        string username;
        string useraddress;
        string email;
        string mobno;
        string department;
        string bookid;
        string bookname;
        string publicname;
        string authname;
        string semester;
        int quantity;
        public bookissuefromadmin()
        {
            InitializeComponent();
        }

        private void bookissuefromadmin_Load(object sender, EventArgs e)
        {
            adminnamelbl.Text = logindata.adminname;
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice1 = guna2ComboBox1.SelectedItem.ToString();
            if(guna2ComboBox1.Text == choice1)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM USERDATA WHERE designation = '" + choice1 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    while(dr.Read())
                    {
                        guna2ComboBox2.Items.Add(dr["name"].ToString());
                    }
                    con.CloseConnection();
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
        }

        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice2 = guna2ComboBox2.SelectedItem.ToString();
            if(guna2ComboBox2.Text == choice2)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM USERDATA WHERE name = '" + choice2 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    dr.Read();
                    useridlbl.Text = "UID : " + dr["id"].ToString();
                    uid = dr["id"].ToString();
                    usernamelbl.Text = "USER NAME : " + dr["name"].ToString();
                    username = dr["name"].ToString();
                    useraddlbl.Text = "ADDRESS : " + dr["address"].ToString();
                    useraddress = dr["address"].ToString();
                    useremaillbl.Text = "EMAIL : " + dr["email"].ToString();
                    email = dr["email"].ToString();
                    usermobnolbl.Text = "MOBILE NUMBER : " + dr["mobno"].ToString();
                    mobno = dr["mobno"].ToString();
                    userdepartmentlbl.Text = "DEPARTMENT : " + dr["department"].ToString();
                    department = dr["department"].ToString();
                    con.CloseConnection();
                    guna2GroupBox1.Visible = true;
                    
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                try
                {
                    con.openconnection();
                    sql = "SELECT BOOK_NAME FROM BOOK";
                    SqlDataReader dr = con.DataReader(sql);
                    while (dr.Read())
                    {
                        guna2ComboBox3.Items.Add(dr["BOOK_NAME"].ToString());
                    }
                    con.CloseConnection();
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            admindashboard adm = new admindashboard();
            this.Close();
            adm.Show();
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.adminname = "";
            logindata.adminaddress = "";
            logindata.adminmobilenum = "";
            logindata.adminemail = "";
            logindata.adminusername = "";
            adminlogin adl = new adminlogin();
            this.Close();
            adl.Show();
        }

        private void guna2ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice3 = guna2ComboBox3.SelectedItem.ToString();
            if(guna2ComboBox3.Text == choice3)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM BOOK WHERE BOOK_NAME = '" + choice3 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    dr.Read();
                    bookidlbl.Text = "BOOK ID : " + dr["BOOK_ID"].ToString();
                    bookid = dr["BOOK_ID"].ToString();
                    booknamelbl.Text = "BOOK NAME : " + dr["BOOK_NAME"].ToString();
                    bookname = dr["BOOK_NAME"].ToString();
                    bookpublnamelbl.Text = "PUBLICATION NAME : " + dr["PUBLICATION_NAME"].ToString();
                    publicname = dr["PUBLICATION_NAME"].ToString();
                    bookauthorlbl.Text = "AUTHOR NAME : " + dr["AUTHOR_NAME"].ToString();
                    authname = dr["AUTHOR_NAME"].ToString();
                    bookqtylbl.Text = "QUANTITY : " + dr["QUANTITY"].ToString();
                    quantity = int.Parse(dr["QUANTITY"].ToString());
                    quantity = quantity - 1;
                    semesterlbl.Text = dr["SEMESTER"].ToString();
                    semester = dr["SEMESTER"].ToString();
                    con.CloseConnection();
                    guna2GroupBox2.Visible = true;
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            string issuedate = DateTime.Now.ToString("dd MMM yyyy");
            try
            {
                con.openconnection();
                sql = "UPDATE BOOK SET QUANTITY = " + quantity + " WHERE BOOK_NAME = '" + bookname + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
            }
            catch
            {
                MessageBox.Show("Unable to Update Quantity", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                con.openconnection();
                sql = "INSERT INTO ISSUEDETAIL(USER_DESIGNATION,USER_NAME,USER_ADDRESS,USER_EMAIL,USER_MOBILE_NUMBER,USER_DEPARTMENT,BOOK_ID,BOOK_NAME,PUBLICATION_NAME,AUTHOR_NAME,SEMESTER,ISSUE_DATE) VALUES('" + choice1 + "','" + username + "','" + useraddress + "','" + email + "','" + mobno + "','" + department + "','" + bookid + "','" + bookname + "','" + publicname + "','" + authname + "','" + semester + "','" + issuedate + "')";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Book Issued Successfully", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Unable to insert data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
