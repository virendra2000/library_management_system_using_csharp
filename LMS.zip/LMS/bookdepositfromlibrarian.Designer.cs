﻿
namespace Library_Management_System
{
    partial class bookdepositfromlibrarian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.returndatelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.authornamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.publicationnamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.booknamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookidlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.issueidlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.issuedatelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2ComboBox3 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ComboBox2 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.logoutlbl = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.librariannamelbl = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.librarymanagementDataSet = new Library_Management_System.librarymanagementDataSet();
            this.librarymanagementDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.guna2GroupBox1.SuspendLayout();
            this.bunifuCards1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // returndatelbl
            // 
            this.returndatelbl.BackColor = System.Drawing.Color.Transparent;
            this.returndatelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returndatelbl.ForeColor = System.Drawing.Color.Black;
            this.returndatelbl.Location = new System.Drawing.Point(21, 222);
            this.returndatelbl.Name = "returndatelbl";
            this.returndatelbl.Size = new System.Drawing.Size(128, 22);
            this.returndatelbl.TabIndex = 6;
            this.returndatelbl.Text = "guna2HtmlLabel4";
            // 
            // authornamelbl
            // 
            this.authornamelbl.BackColor = System.Drawing.Color.Transparent;
            this.authornamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.authornamelbl.ForeColor = System.Drawing.Color.Black;
            this.authornamelbl.Location = new System.Drawing.Point(21, 166);
            this.authornamelbl.Name = "authornamelbl";
            this.authornamelbl.Size = new System.Drawing.Size(128, 22);
            this.authornamelbl.TabIndex = 4;
            this.authornamelbl.Text = "guna2HtmlLabel4";
            // 
            // publicationnamelbl
            // 
            this.publicationnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.publicationnamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.publicationnamelbl.ForeColor = System.Drawing.Color.Black;
            this.publicationnamelbl.Location = new System.Drawing.Point(21, 138);
            this.publicationnamelbl.Name = "publicationnamelbl";
            this.publicationnamelbl.Size = new System.Drawing.Size(128, 22);
            this.publicationnamelbl.TabIndex = 3;
            this.publicationnamelbl.Text = "guna2HtmlLabel4";
            // 
            // booknamelbl
            // 
            this.booknamelbl.BackColor = System.Drawing.Color.Transparent;
            this.booknamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booknamelbl.ForeColor = System.Drawing.Color.Black;
            this.booknamelbl.Location = new System.Drawing.Point(21, 110);
            this.booknamelbl.Name = "booknamelbl";
            this.booknamelbl.Size = new System.Drawing.Size(128, 22);
            this.booknamelbl.TabIndex = 2;
            this.booknamelbl.Text = "guna2HtmlLabel4";
            // 
            // bookidlbl
            // 
            this.bookidlbl.BackColor = System.Drawing.Color.Transparent;
            this.bookidlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookidlbl.ForeColor = System.Drawing.Color.Black;
            this.bookidlbl.Location = new System.Drawing.Point(21, 82);
            this.bookidlbl.Name = "bookidlbl";
            this.bookidlbl.Size = new System.Drawing.Size(128, 22);
            this.bookidlbl.TabIndex = 1;
            this.bookidlbl.Text = "guna2HtmlLabel4";
            // 
            // issueidlbl
            // 
            this.issueidlbl.BackColor = System.Drawing.Color.Transparent;
            this.issueidlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.issueidlbl.ForeColor = System.Drawing.Color.Black;
            this.issueidlbl.Location = new System.Drawing.Point(21, 54);
            this.issueidlbl.Name = "issueidlbl";
            this.issueidlbl.Size = new System.Drawing.Size(128, 22);
            this.issueidlbl.TabIndex = 0;
            this.issueidlbl.Text = "guna2HtmlLabel4";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.returndatelbl);
            this.guna2GroupBox1.Controls.Add(this.issuedatelbl);
            this.guna2GroupBox1.Controls.Add(this.authornamelbl);
            this.guna2GroupBox1.Controls.Add(this.publicationnamelbl);
            this.guna2GroupBox1.Controls.Add(this.booknamelbl);
            this.guna2GroupBox1.Controls.Add(this.bookidlbl);
            this.guna2GroupBox1.Controls.Add(this.issueidlbl);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(515, 22);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(393, 271);
            this.guna2GroupBox1.TabIndex = 10;
            this.guna2GroupBox1.Text = "ISSUE DETAIL";
            this.guna2GroupBox1.Visible = false;
            // 
            // issuedatelbl
            // 
            this.issuedatelbl.BackColor = System.Drawing.Color.Transparent;
            this.issuedatelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.issuedatelbl.ForeColor = System.Drawing.Color.Black;
            this.issuedatelbl.Location = new System.Drawing.Point(21, 194);
            this.issuedatelbl.Name = "issuedatelbl";
            this.issuedatelbl.Size = new System.Drawing.Size(128, 22);
            this.issuedatelbl.TabIndex = 5;
            this.issuedatelbl.Text = "guna2HtmlLabel4";
            // 
            // bunifuCards1
            // 
            this.bunifuCards1.BackColor = System.Drawing.Color.White;
            this.bunifuCards1.BorderRadius = 5;
            this.bunifuCards1.BottomSahddow = true;
            this.bunifuCards1.color = System.Drawing.Color.SpringGreen;
            this.bunifuCards1.Controls.Add(this.guna2GroupBox1);
            this.bunifuCards1.Controls.Add(this.guna2Button1);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox3);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel3);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox2);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel2);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel1);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox1);
            this.bunifuCards1.LeftSahddow = false;
            this.bunifuCards1.Location = new System.Drawing.Point(-2, 65);
            this.bunifuCards1.Name = "bunifuCards1";
            this.bunifuCards1.RightSahddow = true;
            this.bunifuCards1.ShadowDepth = 20;
            this.bunifuCards1.Size = new System.Drawing.Size(922, 500);
            this.bunifuCards1.TabIndex = 34;
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 21;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.SpringGreen;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(49, 235);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(180, 45);
            this.guna2Button1.TabIndex = 9;
            this.guna2Button1.Text = "SUBMIT";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2ComboBox3
            // 
            this.guna2ComboBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox3.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox3.FocusedState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox3.FormattingEnabled = true;
            this.guna2ComboBox3.HoverState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.ItemHeight = 30;
            this.guna2ComboBox3.ItemsAppearance.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Location = new System.Drawing.Point(49, 174);
            this.guna2ComboBox3.Name = "guna2ComboBox3";
            this.guna2ComboBox3.ShadowDecoration.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox3.TabIndex = 7;
            this.guna2ComboBox3.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox3_SelectedIndexChanged);
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(49, 146);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(160, 22);
            this.guna2HtmlLabel3.TabIndex = 6;
            this.guna2HtmlLabel3.Text = "SELECT ISSUE_ID";
            // 
            // guna2ComboBox2
            // 
            this.guna2ComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox2.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox2.FocusedState.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox2.FormattingEnabled = true;
            this.guna2ComboBox2.HoverState.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.ItemHeight = 30;
            this.guna2ComboBox2.ItemsAppearance.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Location = new System.Drawing.Point(49, 104);
            this.guna2ComboBox2.Name = "guna2ComboBox2";
            this.guna2ComboBox2.ShadowDecoration.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox2.TabIndex = 4;
            this.guna2ComboBox2.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox2_SelectedIndexChanged);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(49, 79);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(126, 22);
            this.guna2HtmlLabel2.TabIndex = 3;
            this.guna2HtmlLabel2.Text = "SELECT USER";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(49, 9);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(198, 22);
            this.guna2HtmlLabel1.TabIndex = 2;
            this.guna2HtmlLabel1.Text = "SELECT DESIGNATION";
            // 
            // guna2ComboBox1
            // 
            this.guna2ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox1.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox1.FocusedState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox1.FormattingEnabled = true;
            this.guna2ComboBox1.HoverState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.ItemHeight = 30;
            this.guna2ComboBox1.Items.AddRange(new object[] {
            "TEACHING FACULTY",
            "STUDENT"});
            this.guna2ComboBox1.ItemsAppearance.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Location = new System.Drawing.Point(49, 37);
            this.guna2ComboBox1.Name = "guna2ComboBox1";
            this.guna2ComboBox1.ShadowDecoration.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox1.TabIndex = 1;
            this.guna2ComboBox1.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox1_SelectedIndexChanged);
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.SpringGreen;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(560, 28);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(25, 25);
            this.bunifuCustomLabel5.TabIndex = 38;
            this.bunifuCustomLabel5.Text = "<";
            this.bunifuCustomLabel5.Click += new System.EventHandler(this.bunifuCustomLabel5_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.SpringGreen;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(591, 28);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(132, 25);
            this.bunifuCustomLabel1.TabIndex = 37;
            this.bunifuCustomLabel1.Text = "Book Deposit";
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.IconColor = System.Drawing.Color.SpringGreen;
            this.guna2ControlBox2.Location = new System.Drawing.Point(825, 0);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.ShadowDecoration.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox2.TabIndex = 33;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.SpringGreen;
            this.guna2ControlBox1.Location = new System.Drawing.Point(875, 0);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox1.TabIndex = 32;
            // 
            // logoutlbl
            // 
            this.logoutlbl.AutoSize = true;
            this.logoutlbl.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlbl.ForeColor = System.Drawing.Color.SpringGreen;
            this.logoutlbl.Location = new System.Drawing.Point(821, 37);
            this.logoutlbl.Name = "logoutlbl";
            this.logoutlbl.Size = new System.Drawing.Size(84, 25);
            this.logoutlbl.TabIndex = 36;
            this.logoutlbl.Text = "Log Out";
            this.logoutlbl.Click += new System.EventHandler(this.logoutlbl_Click);
            // 
            // librariannamelbl
            // 
            this.librariannamelbl.AutoSize = true;
            this.librariannamelbl.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.librariannamelbl.ForeColor = System.Drawing.Color.SpringGreen;
            this.librariannamelbl.Location = new System.Drawing.Point(8, 28);
            this.librariannamelbl.Name = "librariannamelbl";
            this.librariannamelbl.Size = new System.Drawing.Size(136, 25);
            this.librariannamelbl.TabIndex = 35;
            this.librariannamelbl.Text = "librarianname";
            // 
            // librarymanagementDataSet
            // 
            this.librarymanagementDataSet.DataSetName = "librarymanagementDataSet";
            this.librarymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // librarymanagementDataSetBindingSource
            // 
            this.librarymanagementDataSetBindingSource.DataSource = this.librarymanagementDataSet;
            this.librarymanagementDataSetBindingSource.Position = 0;
            // 
            // bookdepositfromlibrarian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 564);
            this.Controls.Add(this.bunifuCards1);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.guna2ControlBox2);
            this.Controls.Add(this.guna2ControlBox1);
            this.Controls.Add(this.logoutlbl);
            this.Controls.Add(this.librariannamelbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "bookdepositfromlibrarian";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bookdepositfromlibrarian";
            this.Load += new System.EventHandler(this.bookdepositfromlibrarian_Load);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.bunifuCards1.ResumeLayout(false);
            this.bunifuCards1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel returndatelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel authornamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel publicationnamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel booknamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookidlbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel issueidlbl;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel issuedatelbl;
        private Bunifu.Framework.UI.BunifuCards bunifuCards1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel logoutlbl;
        private Bunifu.Framework.UI.BunifuCustomLabel librariannamelbl;
        private librarymanagementDataSet librarymanagementDataSet;
        private System.Windows.Forms.BindingSource librarymanagementDataSetBindingSource;
    }
}