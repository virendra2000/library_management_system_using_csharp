﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class createbranchfromlibrarian : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        public createbranchfromlibrarian()
        {
            InitializeComponent();
        }

        private void createbranchfromlibrarian_Load(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
            try
            {
                con.openconnection();
                sql = "SELECT dept_name FROM BRANCH";
                SqlDataReader dr = con.DataReader(sql);
                while (dr.Read())
                {
                    guna2ComboBox1.Items.Add(dr["dept_name"].ToString());
                }
            }
            catch
            {
                MessageBox.Show("Unable to Load From database", "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.CloseConnection();
            }
        }
        

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (guna2TextBox1.TextLength > 0)
            {
                try
                {
                    con.openconnection();
                    sql = "INSERT INTO BRANCH(dept_name) VALUES('" + guna2TextBox1.Text + "')";
                    con.ExecuteQueries(sql);
                }
                catch
                {
                    MessageBox.Show("Failed to Insert Data , Connection Aborted", "SQL Client Connection Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    con.CloseConnection();
                    MessageBox.Show("Created Department Successfully", "Data Submitted Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Some of your Field is Blank , Please provide input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            
        }

        private void guna2Button2_Click_1(object sender, EventArgs e)
        {
            string dept = guna2ComboBox1.SelectedItem.ToString();
            if (guna2ComboBox1.Text == dept)
            {
                con.openconnection();
                sql = "DELETE BRANCH WHERE dept_name = '" + dept + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Branch Successfully Deleted", "Manage Department", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void bunifuCustomLabel2_Click(object sender, EventArgs e)
        {
            librariandashboard ld = new librariandashboard();
            this.Close();
            ld.Show();
        }
    }
}
