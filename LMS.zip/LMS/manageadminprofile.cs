﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class manageadminprofile : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string adminid;
        public manageadminprofile()
        {
            InitializeComponent();
        }

        private void manageadminprofile_Load(object sender, EventArgs e)
        {
            adminnamelbl.Text = logindata.adminname;
            con.openconnection();
            sql = "SELECT * FROM ADMIN WHERE username = '" + logindata.adminusername + "'";
            SqlDataReader dr = con.DataReader(sql);
            dr.Read();
            adminid = dr["id"].ToString();
            guna2TextBox1.Text = dr["admin_name"].ToString();
            guna2TextBox2.Text = dr["address"].ToString();
            guna2TextBox3.Text = dr["mobilenumber"].ToString();
            guna2TextBox4.Text = dr["email"].ToString();
            guna2TextBox5.Text = dr["username"].ToString();
            con.CloseConnection();
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            admindashboard adm = new admindashboard();
            this.Close();
            adm.Show();
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.adminname = "";
            logindata.adminaddress = "";
            logindata.adminmobilenum = "";
            logindata.adminemail = "";
            logindata.adminusername = "";
            adminlogin adl = new adminlogin();
            this.Close();
            adl.Show();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            try
            {
                con.openconnection();
                sql = "UPDATE ADMIN SET admin_name = '" + guna2TextBox1.Text + "',address = '" + guna2TextBox2.Text + "',mobilenumber = '" + guna2TextBox3.Text + "',email = '" + guna2TextBox4.Text + "',username = '" + guna2TextBox5.Text + "' WHERE id = '" + adminid + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Update Data Successfully","Manage Profile",MessageBoxButtons.OK,MessageBoxIcon.Information);
                logindata.adminusername = guna2TextBox5.Text;
            }
            catch
            {
                MessageBox.Show("Database Couldn't Found to Update", "Manage profile", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            try
            {
                con.openconnection();
                sql = "DELETE FROM ADMIN WHERE username = '" + logindata.adminusername + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Deleted Account Successfully", "Manage Profile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                logindata.adminname = "";
                logindata.adminaddress = "";
                logindata.adminmobilenum = "";
                logindata.adminemail = "";
                logindata.adminusername = "";
                adminlogin adl = new adminlogin();
                this.Close();
                adl.Show();
            }
            catch
            {
                MessageBox.Show("Unable to delete Account", "Manage Profile", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
