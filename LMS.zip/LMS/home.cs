﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            adminregister adr = new adminregister();
            this.Close();
            adr.Show();
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            adminlogin adl = new adminlogin();
            this.Close();
            adl.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timelbl.Text = DateTime.Now.ToString("HH:mm");
            datelbl.Text = DateTime.Now.ToString("dd MMM yyyy");
        }

        private void home_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            librarianregister lr = new librarianregister();
            this.Close();
            lr.Show();
        }

        private void bunifuTileButton5_Click(object sender, EventArgs e)
        {
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }
    }
}
