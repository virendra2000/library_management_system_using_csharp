﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class createuserfromlibrarian : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string dateofbirth;
        public createuserfromlibrarian()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
            if (guna2TextBox1.TextLength > 0 && guna2TextBox2.TextLength > 0 && guna2TextBox3.TextLength > 0 && guna2TextBox4.TextLength > 0 && guna2TextBox5.TextLength > 0 && guna2TextBox6.TextLength > 0 && guna2TextBox7.TextLength > 0 && guna2TextBox8.TextLength > 0)
            {
                string fullname = guna2TextBox1.Text + " " + guna2TextBox2.Text + " " + guna2TextBox3.Text;
                string address = guna2TextBox4.Text;
                if (bunifuDatepicker1.Value >= DateTime.Now)
                {
                    MessageBox.Show("Date of Birth must not be todays date or greater than today's date");
                }
                else
                {
                    DateTime birthdate = bunifuDatepicker1.Value;
                    dateofbirth = birthdate.ToString("dd-MMM-yyyy");
                }
                string email = guna2TextBox5.Text;
                string mobilenum = guna2TextBox6.Text;
                string designation = guna2ComboBox1.SelectedItem.ToString();
                string depart = guna2ComboBox2.SelectedItem.ToString();
                string username = guna2TextBox7.Text;
                string password = guna2TextBox8.Text;
                try
                {
                    con.openconnection();
                    sql = "INSERT INTO USERDATA(name,address,dob,email,mobno,designation,department,username,password) VALUES('" + fullname + "','" + address + "','" + dateofbirth + "','" + email + "','" + mobilenum + "','" + designation + "','" + depart + "','" + username + "','" + password + "')";
                    con.ExecuteQueries(sql);
                    MessageBox.Show("User Registered Successfully", "Registered Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Registration Failed due to unproper connection to database", "Registration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    con.CloseConnection();
                }

            }
            else
            {
                MessageBox.Show("Some of your Field is Blank , Please provide input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            librariandashboard ld = new librariandashboard();
            this.Close();
            ld.Show();
        }

        private void createuserfromlibrarian_Load(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
            try
            {
                con.openconnection();
                sql = "SELECT dept_name FROM BRANCH";
                SqlDataReader dr = con.DataReader(sql);
                while (dr.Read())
                {
                    guna2ComboBox2.Items.Add(dr["dept_name"].ToString());
                }
            }
            catch
            {
                MessageBox.Show("Unable to Load From database", "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.CloseConnection();
            }
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }
    }
}
