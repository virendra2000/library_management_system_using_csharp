﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library_Management_System
{
    public partial class managelibrarianprofile : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string dateofbirth;
        string librarianid;
        public managelibrarianprofile()
        {
            InitializeComponent();
        }

        private void managelibrarianprofile_Load(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
            con.openconnection();
            sql = "SELECT * FROM LIBRARIAN WHERE lib_username = '" + logindata.librarianusername + "' ";
            SqlDataReader dr = con.DataReader(sql);
            dr.Read();
            librarianid = dr["lib_id"].ToString();
            guna2TextBox1.Text = dr["lib_name"].ToString();
            guna2TextBox2.Text = dr["lib_address"].ToString();
            guna2DateTimePicker1.Value = Convert.ToDateTime(dr["lib_dob"].ToString());
            guna2TextBox3.Text = dr["lib_email"].ToString();
            guna2TextBox4.Text = dr["lib_mobno"].ToString();
            guna2TextBox5.Text = dr["lib_username"].ToString();
            con.CloseConnection();
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            librariandashboard ld = new librariandashboard();
            this.Close();
            ld.Show();
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            try
            {
                con.openconnection();
                if (guna2DateTimePicker1.Value >= DateTime.Now)
                {
                    MessageBox.Show("Date of Birth must not be todays date or greater than today's date");
                }
                else
                {
                    DateTime birthdate = guna2DateTimePicker1.Value;
                    dateofbirth = birthdate.ToString("dd-MMM-yyyy");
                }
                sql = "UPDATE LIBRARIAN SET lib_name = '" + guna2TextBox1.Text + "',lib_address = '" + guna2TextBox2.Text + "',lib_dob = '" + dateofbirth + "',lib_email = '" + guna2TextBox3.Text + "',lib_mobno = '" + guna2TextBox4.Text + "',lib_username = '" + guna2TextBox5.Text + "' WHERE lib_id = '" + librarianid + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Updated Data Successfully", "Manage Profile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                logindata.librarianusername = guna2TextBox5.Text;
            }
            catch
            {
                MessageBox.Show("Database Couldn't Found to Update", "Manage profile", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            try
            {
                con.openconnection();
                sql = "DELETE FROM LIBRARIAN WHERE lib_username = '" + logindata.librarianusername + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Deleted Account Successfully", "Manage Profile", MessageBoxButtons.OK, MessageBoxIcon.Information);
                logindata.librarianname = "";
                logindata.librarianemail = "";
                logindata.librarianusername = "";
                librarianlogin ll = new librarianlogin();
                this.Close();
                ll.Show();
            }
            catch
            {
                MessageBox.Show("Unable to delete Account", "Manage Profile", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
