﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Library_Management_System
{

    public partial class createbookfromlibrarian : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string bookname = "";
        string publicationname = "";
        string authorname = "";
        string branch = "";
        string semester = "";
        int quantity;
        public createbookfromlibrarian()
        {
            InitializeComponent();
        }

        private void bunifuCustomLabel1_Click(object sender, EventArgs e)
        {

        }

        private void createbookfromlibrarian_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'librarymanagementDataSet.BRANCH' table. You can move, or remove it, as needed.
            this.bRANCHTableAdapter.Fill(this.librarymanagementDataSet.BRANCH);
            librariannamelbl.Text = logindata.librarianname;
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            librariandashboard ld = new librariandashboard();
            this.Close();
            ld.Show();
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if(guna2TextBox1.TextLength > 0 && guna2TextBox4.TextLength > 0 && guna2TextBox5.TextLength > 0 && guna2TextBox2.TextLength>0)
            {
                bookname = guna2TextBox1.Text;
                publicationname = guna2TextBox4.Text;
                authorname = guna2TextBox5.Text;
                branch = guna2ComboBox1.SelectedItem.ToString();
                semester = guna2ComboBox2.SelectedItem.ToString();
                quantity = int.Parse(guna2TextBox2.Text);
                try
                {
                    con.openconnection();
                    sql = "INSERT INTO BOOK(BOOK_NAME,PUBLICATION_NAME,AUTHOR_NAME,BRANCH,SEMESTER,QUANTITY) VALUES('" + bookname + "','" + publicationname + "','" + authorname + "','" + branch + "','" + semester + "'," + quantity + ")";
                    con.ExecuteQueries(sql);
                    con.CloseConnection();
                    MessageBox.Show("Book Created Successfully", "Admin Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Unable to Make Entries", "Database Connection Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
