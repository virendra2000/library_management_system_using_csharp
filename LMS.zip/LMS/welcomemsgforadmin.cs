﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class welcomemsgforadmin : Form
    {
        public welcomemsgforadmin()
        {
            InitializeComponent();
        }

        private void welcomemsgforadmin_Load(object sender, EventArgs e)
        {
            if (DateTime.Now.Hour < 12)
            {
                guna2HtmlLabel1.Text = "Good Morning - "+ logindata.adminname;
                guna2PictureBox1.Image = Properties.Resources.goodmrng;

            }
            else if (DateTime.Now.Hour < 17)
            {
                guna2HtmlLabel1.Text = "Good Afternoon - "+ logindata.adminname;
                guna2PictureBox1.Image = Properties.Resources.goodafternoon;
            }
            else if (DateTime.Now.Hour < 20)
            {
                guna2HtmlLabel1.Text = "Good Evening - "+ logindata.adminname;
                guna2PictureBox1.Image = Properties.Resources.goodevening;
            }
            else
            {
                guna2HtmlLabel1.Text = "Good Night - "+logindata.adminname;
                guna2HtmlLabel1.ForeColor = Color.White;
                guna2PictureBox1.Image = Properties.Resources.goodnight;
                bunifuCards1.BackColor = Color.Black;
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            admindashboard adm = new admindashboard();
            this.Close();
            adm.Show();
        }
    }
}
