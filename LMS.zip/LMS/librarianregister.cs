﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class librarianregister : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string dateofbirth;
        public librarianregister()
        {
            InitializeComponent();
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            home h = new home();
            this.Close();
            h.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (guna2TextBox1.TextLength > 0 && guna2TextBox2.TextLength > 0 && guna2TextBox3.TextLength > 0 && guna2TextBox4.TextLength > 0 && guna2TextBox5.TextLength > 0 && guna2TextBox6.TextLength > 0 && guna2TextBox7.TextLength > 0 && guna2TextBox8.TextLength > 0)
            {
                try
                {
                    string fullname = guna2TextBox1.Text + " " + guna2TextBox2.Text + " " + guna2TextBox3.Text;
                    string address = guna2TextBox4.Text;
                    if (bunifuDatepicker1.Value >= DateTime.Now)
                    {
                        MessageBox.Show("Date of Birth must not be todays date or greater than today's date");
                    }
                    else
                    {
                        DateTime birthdate = bunifuDatepicker1.Value;
                        dateofbirth = birthdate.ToString("dd-MMM-yyyy");
                    }
                    string email = guna2TextBox5.Text;
                    string mobilenum = guna2TextBox6.Text;
                    string username = guna2TextBox7.Text;
                    string password = guna2TextBox8.Text;
                    con.openconnection();
                    sql = "INSERT INTO LIBRARIAN(lib_name,lib_address,lib_dob,lib_email,lib_mobno,lib_username,lib_password) VALUES('" + fullname + "','" + address + "','" + dateofbirth + "','" + email + "','" + mobilenum + "','" + username + "','" + password + "')";
                    con.ExecuteQueries(sql);
                    MessageBox.Show("Librarian Registered Successfully", "Registered Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.CloseConnection();
                    logindata.librarianname = fullname;
                    logindata.librarianemail = email;
                    logindata.librarianusername = username;
                    librariandashboard ldm = new librariandashboard();
                    this.Close();
                    ldm.Show();
                }
                catch
                {
                    MessageBox.Show("Failed to connect to Database", "Database connection Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                MessageBox.Show("Some of your Field is Blank , Please provide input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
