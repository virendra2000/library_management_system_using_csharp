﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class bookdepositfromlibrarian : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string choice1;
        string choice2;
        string choice3;
        string bookid;
        int quantity;
        public bookdepositfromlibrarian()
        {
            InitializeComponent();
        }

        private void bookdepositfromlibrarian_Load(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {
            librariandashboard ldm = new librariandashboard();
            this.Close();
            ldm.Show();
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice1 = guna2ComboBox1.SelectedItem.ToString();
            if (guna2ComboBox1.Text == choice1)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM ISSUEDETAIL WHERE USER_DESIGNATION = '" + choice1 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    while (dr.Read())
                    {
                        guna2ComboBox2.Items.Add(dr["USER_NAME"].ToString());
                    }
                    con.CloseConnection();
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Issue", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice2 = guna2ComboBox2.SelectedItem.ToString();
            if (guna2ComboBox2.Text == choice2)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM ISSUEDETAIL WHERE USER_DESIGNATION = '" + choice1 + "' AND USER_NAME = '" + choice2 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    while (dr.Read())
                    {
                        guna2ComboBox3.Items.Add(dr["ISSUE_ID"].ToString());
                    }
                    con.CloseConnection();
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void guna2ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            choice3 = guna2ComboBox3.SelectedItem.ToString();
            if (guna2ComboBox3.Text == choice3)
            {
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM ISSUEDETAIL WHERE ISSUE_ID = '" + choice3 + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    dr.Read();
                    issueidlbl.Text = "ISSUE ID : " + choice3;
                    bookidlbl.Text = "BOOK ID : " + dr["BOOK_ID"].ToString();
                    bookid = dr["BOOK_ID"].ToString();
                    booknamelbl.Text = "BOOK NAME : " + dr["BOOK_NAME"].ToString();
                    publicationnamelbl.Text = "PUBLICATION NAME : " + dr["PUBLICATION_NAME"].ToString();
                    authornamelbl.Text = "AUTHOR NAME : " + dr["AUTHOR_NAME"].ToString();
                    issuedatelbl.Text = "ISSUE DATE : " + dr["ISSUE_DATE"].ToString();
                    returndatelbl.Text = "RETURN DATE : " + dr["RETURN_DATE"].ToString();
                    con.CloseConnection();
                    guna2GroupBox1.Visible = true;
                }
                catch
                {
                    MessageBox.Show("Unable to Read data", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.openconnection();
                sql = "SELECT * FROM BOOK WHERE BOOK_ID = '" + bookid + "' ";
                SqlDataReader dr = con.DataReader(sql);
                dr.Read();
                quantity = int.Parse(dr["QUANTITY"].ToString());
                quantity = quantity + 1;
                con.CloseConnection();
            }
            catch
            {
                MessageBox.Show("Unable to Read data", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                con.openconnection();
                sql = "UPDATE BOOK SET QUANTITY = '" + quantity + "' WHERE BOOK_ID = '" + bookid + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
            }
            catch
            {
                MessageBox.Show("Unable to Read data", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string returndate = DateTime.Now.ToString("dd MMM yyyy");
            try
            {
                con.openconnection();
                sql = "UPDATE ISSUEDETAIL SET RETURN_DATE = '" + returndate + "' WHERE ISSUE_ID = '" + choice3 + "' ";
                con.ExecuteQueries(sql);
                con.CloseConnection();
                MessageBox.Show("Book Deposit Successfully", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Unable to Read data", "Book Deposit", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
