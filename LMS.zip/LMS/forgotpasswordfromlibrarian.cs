﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class forgotpasswordfromlibrarian : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string username;
        string password;
        public forgotpasswordfromlibrarian()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (guna2TextBox1.TextLength > 0 && guna2TextBox2.TextLength > 0 && guna2TextBox3.TextLength > 0)
            {
                if (guna2TextBox2.Text == guna2TextBox3.Text)
                {
                    try
                    {
                        username = guna2TextBox1.Text;
                        password = guna2TextBox3.Text;
                        con.openconnection();
                        sql = "UPDATE LIBRARIAN SET lib_password = '" + password + "' WHERE lib_username = '" + username + "' ";
                        con.ExecuteQueries(sql);
                    }
                    catch
                    {
                        MessageBox.Show("Unable to fetch previous data", "Account Fetching Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        con.CloseConnection();
                        MessageBox.Show("New Password Set Successfully", "Password Changed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        guna2TextBox1.ResetText();
                        guna2TextBox2.ResetText();
                        guna2TextBox3.ResetText();
                        adminlogin adl = new adminlogin();
                        this.Close();
                        adl.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Confirm Password Doesn't Match", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Invalid Input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
