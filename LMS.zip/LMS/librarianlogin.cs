﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Library_Management_System
{
    public partial class librarianlogin : Form
    {
        databaseconn con = new databaseconn();
        string sql;
        string username;
        string password;
        public librarianlogin()
        {
            InitializeComponent();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            librarianregister lr = new librarianregister();
            this.Close();
            lr.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            home h = new home();
            this.Close();
            h.Show();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            forgotpasswordfromlibrarian fgl = new forgotpasswordfromlibrarian();
            this.Close();
            fgl.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (guna2TextBox1.TextLength > 0 && guna2TextBox2.TextLength > 0)
            {
                username = guna2TextBox1.Text;
                password = guna2TextBox2.Text;
                try
                {
                    con.openconnection();
                    sql = "SELECT * FROM LIBRARIAN WHERE lib_username='" + username + "' AND lib_password = '" + password + "' ";
                    SqlDataReader dr = con.DataReader(sql);
                    dr.Read();
                    logindata.librarianname = dr["lib_name"].ToString();
                    logindata.librarianemail = dr["lib_email"].ToString();
                    logindata.librarianusername = dr["lib_username"].ToString();
                    MessageBox.Show("Login Successfully", "Login Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    welcomemsgforlibrarian wml = new welcomemsgforlibrarian();
                    this.Close();
                    wml.Show();
                    con.CloseConnection();
                    guna2TextBox1.ResetText();
                    guna2TextBox2.ResetText();
                }
                catch
                {
                    MessageBox.Show("Login Failed", "Login Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    MessageBox.Show("You have not registered Yet", "Librarian Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    librarianregister lr = new librarianregister();
                    this.Close();
                    lr.Show();
                }
            }
            else
            {
                MessageBox.Show("Invalid Input , Please Provide Valid Input", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
