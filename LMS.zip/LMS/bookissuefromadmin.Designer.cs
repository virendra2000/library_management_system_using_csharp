﻿
namespace Library_Management_System
{
    partial class bookissuefromadmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuCards1 = new Bunifu.Framework.UI.BunifuCards();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.logoutlbl = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.adminnamelbl = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ComboBox2 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.useridlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.usernamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.useraddlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.useremaillbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.usermobnolbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.userdepartmentlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ComboBox3 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.librarymanagementDataSet = new Library_Management_System.librarymanagementDataSet();
            this.librarymanagementDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.bookidlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.booknamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookpublnamelbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookauthorlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookqtylbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.semesterlbl = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bunifuCards1.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSetBindingSource)).BeginInit();
            this.guna2GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuCards1
            // 
            this.bunifuCards1.BackColor = System.Drawing.Color.White;
            this.bunifuCards1.BorderRadius = 5;
            this.bunifuCards1.BottomSahddow = true;
            this.bunifuCards1.color = System.Drawing.Color.SpringGreen;
            this.bunifuCards1.Controls.Add(this.guna2Button1);
            this.bunifuCards1.Controls.Add(this.guna2GroupBox2);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox3);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel3);
            this.bunifuCards1.Controls.Add(this.guna2GroupBox1);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox2);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel2);
            this.bunifuCards1.Controls.Add(this.guna2HtmlLabel1);
            this.bunifuCards1.Controls.Add(this.guna2ComboBox1);
            this.bunifuCards1.LeftSahddow = false;
            this.bunifuCards1.Location = new System.Drawing.Point(-1, 64);
            this.bunifuCards1.Name = "bunifuCards1";
            this.bunifuCards1.RightSahddow = true;
            this.bunifuCards1.ShadowDepth = 20;
            this.bunifuCards1.Size = new System.Drawing.Size(922, 500);
            this.bunifuCards1.TabIndex = 18;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.IconColor = System.Drawing.Color.SpringGreen;
            this.guna2ControlBox2.Location = new System.Drawing.Point(826, -1);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.ShadowDecoration.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox2.TabIndex = 17;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.SpringGreen;
            this.guna2ControlBox1.Location = new System.Drawing.Point(876, -1);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox1.TabIndex = 16;
            // 
            // logoutlbl
            // 
            this.logoutlbl.AutoSize = true;
            this.logoutlbl.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutlbl.ForeColor = System.Drawing.Color.SpringGreen;
            this.logoutlbl.Location = new System.Drawing.Point(822, 36);
            this.logoutlbl.Name = "logoutlbl";
            this.logoutlbl.Size = new System.Drawing.Size(84, 25);
            this.logoutlbl.TabIndex = 20;
            this.logoutlbl.Text = "Log Out";
            this.logoutlbl.Click += new System.EventHandler(this.logoutlbl_Click);
            // 
            // adminnamelbl
            // 
            this.adminnamelbl.AutoSize = true;
            this.adminnamelbl.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminnamelbl.ForeColor = System.Drawing.Color.SpringGreen;
            this.adminnamelbl.Location = new System.Drawing.Point(9, 27);
            this.adminnamelbl.Name = "adminnamelbl";
            this.adminnamelbl.Size = new System.Drawing.Size(117, 25);
            this.adminnamelbl.TabIndex = 19;
            this.adminnamelbl.Text = "adminname";
            // 
            // guna2ComboBox1
            // 
            this.guna2ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox1.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox1.FocusedState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox1.FormattingEnabled = true;
            this.guna2ComboBox1.HoverState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.ItemHeight = 30;
            this.guna2ComboBox1.Items.AddRange(new object[] {
            "TEACHING FACULTY",
            "STUDENT"});
            this.guna2ComboBox1.ItemsAppearance.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Location = new System.Drawing.Point(49, 37);
            this.guna2ComboBox1.Name = "guna2ComboBox1";
            this.guna2ComboBox1.ShadowDecoration.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox1.TabIndex = 1;
            this.guna2ComboBox1.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox1_SelectedIndexChanged);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(49, 9);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(198, 22);
            this.guna2HtmlLabel1.TabIndex = 2;
            this.guna2HtmlLabel1.Text = "SELECT DESIGNATION";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(49, 79);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(126, 22);
            this.guna2HtmlLabel2.TabIndex = 3;
            this.guna2HtmlLabel2.Text = "SELECT USER";
            // 
            // guna2ComboBox2
            // 
            this.guna2ComboBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox2.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox2.FocusedState.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox2.FormattingEnabled = true;
            this.guna2ComboBox2.HoverState.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.ItemHeight = 30;
            this.guna2ComboBox2.ItemsAppearance.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Location = new System.Drawing.Point(49, 104);
            this.guna2ComboBox2.Name = "guna2ComboBox2";
            this.guna2ComboBox2.ShadowDecoration.Parent = this.guna2ComboBox2;
            this.guna2ComboBox2.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox2.TabIndex = 4;
            this.guna2ComboBox2.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox2_SelectedIndexChanged);
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.guna2GroupBox1.Controls.Add(this.userdepartmentlbl);
            this.guna2GroupBox1.Controls.Add(this.usermobnolbl);
            this.guna2GroupBox1.Controls.Add(this.useremaillbl);
            this.guna2GroupBox1.Controls.Add(this.useraddlbl);
            this.guna2GroupBox1.Controls.Add(this.usernamelbl);
            this.guna2GroupBox1.Controls.Add(this.useridlbl);
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox1.Location = new System.Drawing.Point(510, 14);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.ShadowDecoration.Parent = this.guna2GroupBox1;
            this.guna2GroupBox1.Size = new System.Drawing.Size(397, 244);
            this.guna2GroupBox1.TabIndex = 5;
            this.guna2GroupBox1.Text = "USER DETAIL";
            this.guna2GroupBox1.Visible = false;
            // 
            // useridlbl
            // 
            this.useridlbl.BackColor = System.Drawing.Color.Transparent;
            this.useridlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useridlbl.ForeColor = System.Drawing.Color.Black;
            this.useridlbl.Location = new System.Drawing.Point(9, 48);
            this.useridlbl.Name = "useridlbl";
            this.useridlbl.Size = new System.Drawing.Size(128, 22);
            this.useridlbl.TabIndex = 0;
            this.useridlbl.Text = "guna2HtmlLabel3";
            // 
            // usernamelbl
            // 
            this.usernamelbl.BackColor = System.Drawing.Color.Transparent;
            this.usernamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernamelbl.ForeColor = System.Drawing.Color.Black;
            this.usernamelbl.Location = new System.Drawing.Point(9, 76);
            this.usernamelbl.Name = "usernamelbl";
            this.usernamelbl.Size = new System.Drawing.Size(128, 22);
            this.usernamelbl.TabIndex = 1;
            this.usernamelbl.Text = "guna2HtmlLabel4";
            // 
            // useraddlbl
            // 
            this.useraddlbl.BackColor = System.Drawing.Color.Transparent;
            this.useraddlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useraddlbl.ForeColor = System.Drawing.Color.Black;
            this.useraddlbl.Location = new System.Drawing.Point(9, 104);
            this.useraddlbl.Name = "useraddlbl";
            this.useraddlbl.Size = new System.Drawing.Size(128, 22);
            this.useraddlbl.TabIndex = 2;
            this.useraddlbl.Text = "guna2HtmlLabel5";
            // 
            // useremaillbl
            // 
            this.useremaillbl.BackColor = System.Drawing.Color.Transparent;
            this.useremaillbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.useremaillbl.ForeColor = System.Drawing.Color.Black;
            this.useremaillbl.Location = new System.Drawing.Point(9, 132);
            this.useremaillbl.Name = "useremaillbl";
            this.useremaillbl.Size = new System.Drawing.Size(128, 22);
            this.useremaillbl.TabIndex = 3;
            this.useremaillbl.Text = "guna2HtmlLabel6";
            // 
            // usermobnolbl
            // 
            this.usermobnolbl.BackColor = System.Drawing.Color.Transparent;
            this.usermobnolbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usermobnolbl.ForeColor = System.Drawing.Color.Black;
            this.usermobnolbl.Location = new System.Drawing.Point(9, 160);
            this.usermobnolbl.Name = "usermobnolbl";
            this.usermobnolbl.Size = new System.Drawing.Size(128, 22);
            this.usermobnolbl.TabIndex = 4;
            this.usermobnolbl.Text = "guna2HtmlLabel7";
            // 
            // userdepartmentlbl
            // 
            this.userdepartmentlbl.BackColor = System.Drawing.Color.Transparent;
            this.userdepartmentlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userdepartmentlbl.ForeColor = System.Drawing.Color.Black;
            this.userdepartmentlbl.Location = new System.Drawing.Point(9, 188);
            this.userdepartmentlbl.Name = "userdepartmentlbl";
            this.userdepartmentlbl.Size = new System.Drawing.Size(128, 22);
            this.userdepartmentlbl.TabIndex = 5;
            this.userdepartmentlbl.Text = "guna2HtmlLabel8";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.SpringGreen;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(561, 27);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(25, 25);
            this.bunifuCustomLabel5.TabIndex = 24;
            this.bunifuCustomLabel5.Text = "<";
            this.bunifuCustomLabel5.Click += new System.EventHandler(this.bunifuCustomLabel5_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.SpringGreen;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(592, 27);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(108, 25);
            this.bunifuCustomLabel1.TabIndex = 23;
            this.bunifuCustomLabel1.Text = "Book Issue";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(49, 146);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(125, 22);
            this.guna2HtmlLabel3.TabIndex = 6;
            this.guna2HtmlLabel3.Text = "SELECT BOOK";
            // 
            // guna2ComboBox3
            // 
            this.guna2ComboBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox3.FocusedColor = System.Drawing.Color.Empty;
            this.guna2ComboBox3.FocusedState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox3.FormattingEnabled = true;
            this.guna2ComboBox3.HoverState.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.ItemHeight = 30;
            this.guna2ComboBox3.ItemsAppearance.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Location = new System.Drawing.Point(49, 174);
            this.guna2ComboBox3.Name = "guna2ComboBox3";
            this.guna2ComboBox3.ShadowDecoration.Parent = this.guna2ComboBox3;
            this.guna2ComboBox3.Size = new System.Drawing.Size(403, 36);
            this.guna2ComboBox3.TabIndex = 7;
            this.guna2ComboBox3.SelectedIndexChanged += new System.EventHandler(this.guna2ComboBox3_SelectedIndexChanged);
            // 
            // librarymanagementDataSet
            // 
            this.librarymanagementDataSet.DataSetName = "librarymanagementDataSet";
            this.librarymanagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // librarymanagementDataSetBindingSource
            // 
            this.librarymanagementDataSetBindingSource.DataSource = this.librarymanagementDataSet;
            this.librarymanagementDataSetBindingSource.Position = 0;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Controls.Add(this.semesterlbl);
            this.guna2GroupBox2.Controls.Add(this.bookqtylbl);
            this.guna2GroupBox2.Controls.Add(this.bookauthorlbl);
            this.guna2GroupBox2.Controls.Add(this.bookpublnamelbl);
            this.guna2GroupBox2.Controls.Add(this.booknamelbl);
            this.guna2GroupBox2.Controls.Add(this.bookidlbl);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(510, 264);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.ShadowDecoration.Parent = this.guna2GroupBox2;
            this.guna2GroupBox2.Size = new System.Drawing.Size(397, 224);
            this.guna2GroupBox2.TabIndex = 8;
            this.guna2GroupBox2.Text = "BOOK DETAIL";
            this.guna2GroupBox2.Visible = false;
            // 
            // bookidlbl
            // 
            this.bookidlbl.BackColor = System.Drawing.Color.Transparent;
            this.bookidlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookidlbl.ForeColor = System.Drawing.Color.Black;
            this.bookidlbl.Location = new System.Drawing.Point(9, 47);
            this.bookidlbl.Name = "bookidlbl";
            this.bookidlbl.Size = new System.Drawing.Size(128, 22);
            this.bookidlbl.TabIndex = 6;
            this.bookidlbl.Text = "guna2HtmlLabel8";
            // 
            // booknamelbl
            // 
            this.booknamelbl.BackColor = System.Drawing.Color.Transparent;
            this.booknamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booknamelbl.ForeColor = System.Drawing.Color.Black;
            this.booknamelbl.Location = new System.Drawing.Point(9, 75);
            this.booknamelbl.Name = "booknamelbl";
            this.booknamelbl.Size = new System.Drawing.Size(128, 22);
            this.booknamelbl.TabIndex = 7;
            this.booknamelbl.Text = "guna2HtmlLabel8";
            // 
            // bookpublnamelbl
            // 
            this.bookpublnamelbl.BackColor = System.Drawing.Color.Transparent;
            this.bookpublnamelbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookpublnamelbl.ForeColor = System.Drawing.Color.Black;
            this.bookpublnamelbl.Location = new System.Drawing.Point(9, 103);
            this.bookpublnamelbl.Name = "bookpublnamelbl";
            this.bookpublnamelbl.Size = new System.Drawing.Size(128, 22);
            this.bookpublnamelbl.TabIndex = 8;
            this.bookpublnamelbl.Text = "guna2HtmlLabel8";
            // 
            // bookauthorlbl
            // 
            this.bookauthorlbl.BackColor = System.Drawing.Color.Transparent;
            this.bookauthorlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookauthorlbl.ForeColor = System.Drawing.Color.Black;
            this.bookauthorlbl.Location = new System.Drawing.Point(9, 131);
            this.bookauthorlbl.Name = "bookauthorlbl";
            this.bookauthorlbl.Size = new System.Drawing.Size(128, 22);
            this.bookauthorlbl.TabIndex = 9;
            this.bookauthorlbl.Text = "guna2HtmlLabel8";
            // 
            // bookqtylbl
            // 
            this.bookqtylbl.BackColor = System.Drawing.Color.Transparent;
            this.bookqtylbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookqtylbl.ForeColor = System.Drawing.Color.Black;
            this.bookqtylbl.Location = new System.Drawing.Point(9, 159);
            this.bookqtylbl.Name = "bookqtylbl";
            this.bookqtylbl.Size = new System.Drawing.Size(128, 22);
            this.bookqtylbl.TabIndex = 10;
            this.bookqtylbl.Text = "guna2HtmlLabel8";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BorderRadius = 21;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.SpringGreen;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(49, 235);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(180, 45);
            this.guna2Button1.TabIndex = 9;
            this.guna2Button1.Text = "SUBMIT";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // semesterlbl
            // 
            this.semesterlbl.BackColor = System.Drawing.Color.Transparent;
            this.semesterlbl.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semesterlbl.ForeColor = System.Drawing.Color.Black;
            this.semesterlbl.Location = new System.Drawing.Point(9, 187);
            this.semesterlbl.Name = "semesterlbl";
            this.semesterlbl.Size = new System.Drawing.Size(128, 22);
            this.semesterlbl.TabIndex = 11;
            this.semesterlbl.Text = "guna2HtmlLabel8";
            // 
            // bookissuefromadmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 564);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.bunifuCards1);
            this.Controls.Add(this.guna2ControlBox2);
            this.Controls.Add(this.guna2ControlBox1);
            this.Controls.Add(this.logoutlbl);
            this.Controls.Add(this.adminnamelbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "bookissuefromadmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bookissuefromadmin";
            this.Load += new System.EventHandler(this.bookissuefromadmin_Load);
            this.bunifuCards1.ResumeLayout(false);
            this.bunifuCards1.PerformLayout();
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.librarymanagementDataSetBindingSource)).EndInit();
            this.guna2GroupBox2.ResumeLayout(false);
            this.guna2GroupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCards bunifuCards1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel logoutlbl;
        private Bunifu.Framework.UI.BunifuCustomLabel adminnamelbl;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel useraddlbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel usernamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel useridlbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel userdepartmentlbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel usermobnolbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel useremaillbl;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private librarymanagementDataSet librarymanagementDataSet;
        private System.Windows.Forms.BindingSource librarymanagementDataSetBindingSource;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookqtylbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookauthorlbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookpublnamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel booknamelbl;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookidlbl;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2HtmlLabel semesterlbl;
    }
}