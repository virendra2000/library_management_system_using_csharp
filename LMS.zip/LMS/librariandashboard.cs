﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class librariandashboard : Form
    {
        public librariandashboard()
        {
            InitializeComponent();
        }

        private void librariandashboard_Load(object sender, EventArgs e)
        {
            librariannamelbl.Text = logindata.librarianname;
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.librarianname = "";
            logindata.librarianemail = "";
            logindata.librarianusername = "";
            librarianlogin ll = new librarianlogin();
            this.Close();
            ll.Show();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            createuserfromlibrarian cul = new createuserfromlibrarian();
            this.Close();
            cul.Show();
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            createbranchfromlibrarian cbl = new createbranchfromlibrarian();
            this.Close();
            cbl.Show();
        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            createbookfromlibrarian cbl = new createbookfromlibrarian();
            this.Close();
            cbl.Show();
        }

        private void bunifuTileButton8_Click(object sender, EventArgs e)
        {
            managelibrarianprofile mlp = new managelibrarianprofile();
            this.Close();
            mlp.Show();
        }

        private void bunifuTileButton6_Click(object sender, EventArgs e)
        {
            bookissuefromlibrarian bil = new bookissuefromlibrarian();
            this.Close();
            bil.Show();
        }

        private void bunifuTileButton7_Click(object sender, EventArgs e)
        {
            bookdepositfromlibrarian bdl = new bookdepositfromlibrarian();
            this.Close();
            bdl.Show();
        }
    }
}
