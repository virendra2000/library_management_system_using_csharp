﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    class logindata
    {
        //login data of admin
        public static string adminname = "";
        public static string adminaddress = "";
        public static string adminmobilenum = "";
        public static string adminemail = "";
        public static string adminusername = "";

        //login data of librarian
        public static string librarianname = "";
        public static string librarianemail = "";
        public static string librarianusername = "";
    }
}
