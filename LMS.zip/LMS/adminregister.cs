﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class adminregister : Form
    {
        databaseconn con = new databaseconn();
        string name;
        string address;
        string mobilenum;
        string email;
        string username;
        string password;
        string sql;
        public adminregister()
        {
            InitializeComponent();
        }
        private void guna2Button2_Click(object sender, EventArgs e)
        {
            home h = new home();
            this.Close();
            h.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if(guna2TextBox1.TextLength>0 && guna2TextBox2.TextLength>0 && guna2TextBox3.TextLength>0 && guna2TextBox4.TextLength>0 && guna2TextBox5.TextLength>0 && guna2TextBox6.TextLength>0)
            {
                name = guna2TextBox1.Text;
                address = guna2TextBox2.Text;
                mobilenum = guna2TextBox3.Text;
                email = guna2TextBox4.Text;
                username = guna2TextBox5.Text;
                password = guna2TextBox6.Text;
                try
                {
                    con.openconnection();
                    sql = "INSERT INTO ADMIN(admin_name,address,mobilenumber,email,username,password) VALUES('" + name + "','" + address + "','" + mobilenum + "','" + email + "','" + username + "','" + password + "')";
                    con.ExecuteQueries(sql);
                    MessageBox.Show("Register Successfully", "Account Created", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.CloseConnection();
                    logindata.adminname = name;
                    logindata.adminaddress = address;
                    logindata.adminmobilenum = mobilenum;
                    logindata.adminemail = email;
                    logindata.adminusername = username;
                    admindashboard adm = new admindashboard();
                    this.Close();
                    adm.Show();
                    guna2TextBox1.ResetText();
                    guna2TextBox2.ResetText();
                    guna2TextBox3.ResetText();
                    guna2TextBox4.ResetText();
                    guna2TextBox5.ResetText();
                    guna2TextBox6.ResetText();
                }
                catch
                {
                    MessageBox.Show("Registration Failed due to unproper connection to database","Registration Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Some of your Field is Blank , Please provide input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
