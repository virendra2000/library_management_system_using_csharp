﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class admindashboard : Form
    {
        public admindashboard()
        {
            InitializeComponent();
        }

        private void admindashboard_Load(object sender, EventArgs e)
        {
            adminnamelbl.Text = logindata.adminname;
            
        }

        private void logoutlbl_Click(object sender, EventArgs e)
        {
            logindata.adminname = "";
            logindata.adminaddress = "";
            logindata.adminmobilenum = "";
            logindata.adminemail = "";
            logindata.adminusername = "";
            adminlogin adl = new adminlogin();
            this.Close();
            adl.Show();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            createuserfromadmin cu = new createuserfromadmin();
            this.Close();
            cu.Show();
        }

        private void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            createlibrarianfromadmin cl = new createlibrarianfromadmin();
            this.Close();
            cl.Show();
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            createbranchfromadmin cb = new createbranchfromadmin();
            this.Close();
            cb.Show();
        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            createbookfromadmin cba = new createbookfromadmin();
            this.Close();
            cba.Show();
        }

        private void adminnamelbl_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTileButton8_Click(object sender, EventArgs e)
        {
            manageadminprofile map = new manageadminprofile();
            this.Close();
            map.Show();
        }

        private void bunifuTileButton6_Click(object sender, EventArgs e)
        {
            bookissuefromadmin bia = new bookissuefromadmin();
            this.Close();
            bia.Show();
        }

        private void bunifuTileButton7_Click(object sender, EventArgs e)
        {
            bookdepositfromadmin bda = new bookdepositfromadmin();
            this.Close();
            bda.Show();
        }
    }
}
